In a demo-scene I showed how to use the split animation (but it's only if the character is controlled by a script or physics). 
Note, please, that only new animations (Update 1.1) are used and shown there. You'll have to add other animations to 'Animator' and also set up transitions between them. 
You can customize everything to fit your needs using Mecanim settings.